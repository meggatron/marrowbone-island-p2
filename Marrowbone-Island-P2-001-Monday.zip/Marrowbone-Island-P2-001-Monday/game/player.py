# game/player.py

player_name = ""
# inventory = []

